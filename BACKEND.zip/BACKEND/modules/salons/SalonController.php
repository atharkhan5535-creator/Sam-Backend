<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../core/Request.php';
require_once __DIR__ . '/../../core/Response.php';

class SalonController
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /*
    |--------------------------------------------------------------------------
    | 1️⃣ CREATE SALON (SUPER_ADMIN only)
    |--------------------------------------------------------------------------
    */
    public function create()
    {
        $data = json_decode(file_get_contents("php://input"), true);

        $salonName = trim($data['salon_name'] ?? '');
        $salonOwnerName = trim($data['salon_ownername'] ?? '');
        $email = trim($data['email'] ?? '');
        $phone = trim($data['phone'] ?? '');
        $gstNum = trim($data['gst_num'] ?? '');
        $address = trim($data['address'] ?? '');
        $city = trim($data['city'] ?? '');
        $state = trim($data['state'] ?? '');
        $country = trim($data['country'] ?? 'India');
        $salonLogo = trim($data['salon_logo'] ?? '');
        $status = $data['status'] ?? 1;

        // Validation
        if (!$salonName || !$salonOwnerName || !$email || !$phone || !$address || !$city || !$state) {
            Response::json(["status" => "error", "message" => "Salon name, owner name, email, phone, address, city, and state are required"], 400);
        }

        // Email validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            Response::json(["status" => "error", "message" => "Invalid email format"], 400);
        }

        // Phone validation (10 digit Indian)
        if (!preg_match("/^[6-9][0-9]{9}$/", $phone)) {
            Response::json(["status" => "error", "message" => "Invalid phone number (10 digit Indian format required)"], 400);
        }

        // GST validation (Indian format) - optional field
        if ($gstNum && !preg_match("/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/", strtoupper($gstNum))) {
            Response::json(["status" => "error", "message" => "Invalid GST number format"], 400);
        }

        // Check duplicate email
        $stmt = $this->db->prepare("SELECT salon_id FROM salons WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            Response::json(["status" => "error", "message" => "Email already registered"], 409);
        }

        // Check duplicate GST (if provided)
        if ($gstNum) {
            $stmt = $this->db->prepare("SELECT salon_id FROM salons WHERE gst_num = ?");
            $stmt->execute([strtoupper($gstNum)]);
            if ($stmt->fetch()) {
                Response::json(["status" => "error", "message" => "GST number already registered"], 409);
            }
        }

        try {
            $stmt = $this->db->prepare("
                INSERT INTO salons
                (salon_name, salon_ownername, email, phone, gst_num, address, city, state, country, salon_logo, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $salonName,
                $salonOwnerName,
                $email,
                $phone,
                $gstNum ? strtoupper($gstNum) : null,
                $address,
                $city,
                $state,
                $country,
                $salonLogo ?: null,
                $status
            ]);

            Response::json([
                "status" => "success",
                "data" => [
                    "salon_id" => $this->db->lastInsertId()
                ]
            ], 201);

        } catch (Exception $e) {
            Response::json([
                "status" => "error",
                "message" => "Failed to create salon: " . $e->getMessage()
            ], 500);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | 2️⃣ UPDATE SALON (SUPER_ADMIN only)
    |--------------------------------------------------------------------------
    */
    public function update($salonId)
    {
        // Verify salon exists
        $stmt = $this->db->prepare("SELECT * FROM salons WHERE salon_id = ?");
        $stmt->execute([$salonId]);
        $salon = $stmt->fetch();

        if (!$salon) {
            Response::json(["status" => "error", "message" => "Salon not found"], 404);
        }

        $data = json_decode(file_get_contents("php://input"), true);

        $allowedFields = [
            'salon_name', 'salon_ownername', 'email', 'phone', 'gst_num',
            'address', 'city', 'state', 'country', 'salon_logo'
        ];

        $updates = [];
        $values = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $values[] = $data[$field];
            }
        }

        if (empty($updates)) {
            Response::json(["status" => "error", "message" => "No valid fields to update"], 400);
        }

        // Check duplicate email (exclude current salon)
        if (isset($data['email']) && $data['email'] !== $salon['email']) {
            $stmt = $this->db->prepare("SELECT salon_id FROM salons WHERE email = ? AND salon_id != ?");
            $stmt->execute([$data['email'], $salonId]);
            if ($stmt->fetch()) {
                Response::json(["status" => "error", "message" => "Email already registered"], 409);
            }
        }

        // Check duplicate GST (exclude current salon)
        if (isset($data['gst_num']) && strtoupper($data['gst_num']) !== $salon['gst_num']) {
            $stmt = $this->db->prepare("SELECT salon_id FROM salons WHERE gst_num = ? AND salon_id != ?");
            $stmt->execute([strtoupper($data['gst_num']), $salonId]);
            if ($stmt->fetch()) {
                Response::json(["status" => "error", "message" => "GST number already registered"], 409);
            }
        }

        $values[] = $salonId;

        $sql = "UPDATE salons SET " . implode(', ', $updates) . ", updated_at = NOW()
                WHERE salon_id = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($values);

        Response::json([
            "status" => "success"
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 3️⃣ TOGGLE SALON STATUS (SUPER_ADMIN only)
    |--------------------------------------------------------------------------
    */
    public function toggleStatus($salonId)
    {
        // Verify salon exists
        $stmt = $this->db->prepare("SELECT * FROM salons WHERE salon_id = ?");
        $stmt->execute([$salonId]);
        $salon = $stmt->fetch();

        if (!$salon) {
            Response::json(["status" => "error", "message" => "Salon not found"], 404);
        }

        $data = json_decode(file_get_contents("php://input"), true);
        $status = $data['status'] ?? null;

        if ($status === null || !in_array($status, [0, 1])) {
            Response::json(["status" => "error", "message" => "Status must be 0 (inactive) or 1 (active)"], 400);
        }

        $stmt = $this->db->prepare("
            UPDATE salons
            SET status = ?, updated_at = NOW()
            WHERE salon_id = ?
        ");

        $stmt->execute([$status, $salonId]);

        Response::json([
            "status" => "success"
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 4️⃣ LIST SALONS (SUPER_ADMIN only)
    |--------------------------------------------------------------------------
    */
    public function index()
    {
        $status = $_GET['status'] ?? null;

        $sql = "SELECT * FROM salons WHERE 1=1";
        $params = [];

        if ($status !== null) {
            $sql .= " AND status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY created_at DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $salons = $stmt->fetchAll(PDO::FETCH_ASSOC);

        Response::json([
            "status" => "success",
            "data" => [
                "items" => $salons,
                "total" => count($salons)
            ]
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 5️⃣ VIEW SALON DETAILS (SUPER_ADMIN only)
    |--------------------------------------------------------------------------
    */
    public function show($salonId)
    {
        $stmt = $this->db->prepare("SELECT * FROM salons WHERE salon_id = ?");
        $stmt->execute([$salonId]);
        $salon = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$salon) {
            Response::json(["status" => "error", "message" => "Salon not found"], 404);
        }

        Response::json([
            "status" => "success",
            "data" => $salon
        ]);
    }
}
