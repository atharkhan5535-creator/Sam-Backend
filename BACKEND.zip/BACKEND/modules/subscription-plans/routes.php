<?php

require_once __DIR__ . '/SubscriptionPlanController.php';
require_once __DIR__ . '/../../middlewares/authenticate.php';
require_once __DIR__ . '/../../middlewares/authorize.php';

$controller = new SubscriptionPlanController();

/*
|--------------------------------------------------------------------------
| SUBSCRIPTION PLAN ROUTES (SUPER_ADMIN for write, ADMIN/STAFF for read)
| NOTE: CUSTOMERS do NOT have access to subscription APIs
|--------------------------------------------------------------------------
*/

// 1️⃣ Create Subscription Plan (SUPER_ADMIN only)
$router->register(
    'POST',
    '/api/subscription-plans',
    function() use ($controller) {
        authorize(['SUPER_ADMIN']);
        $controller->create();
    }
);

// 2️⃣ Update Subscription Plan (SUPER_ADMIN only)
$router->register(
    'PUT',
    '/api/subscription-plans/{plan_id}',
    function($planId) use ($controller) {
        authorize(['SUPER_ADMIN']);
        $controller->update($planId);
    }
);

// 3️⃣ List Subscription Plans (ADMIN, STAFF only - NOT PUBLIC)
$router->register(
    'GET',
    '/api/subscription-plans',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->index();
    }
);

// 4️⃣ View Subscription Plan Details (ADMIN, STAFF only - NOT PUBLIC)
$router->register(
    'GET',
    '/api/subscription-plans/{plan_id}',
    function($planId) use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->show($planId);
    }
);

// 5️⃣ Toggle Plan Status (SUPER_ADMIN only)
$router->register(
    'PATCH',
    '/api/subscription-plans/{plan_id}/status',
    function($planId) use ($controller) {
        authorize(['SUPER_ADMIN']);
        $controller->toggleStatus($planId);
    }
);
