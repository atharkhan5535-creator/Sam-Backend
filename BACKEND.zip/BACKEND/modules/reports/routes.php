<?php

require_once __DIR__ . '/ReportController.php';
require_once __DIR__ . '/../../middlewares/authenticate.php';
require_once __DIR__ . '/../../middlewares/authorize.php';

$controller = new ReportController();

/*
|--------------------------------------------------------------------------
| REPORT ROUTES (ADMIN, STAFF only)
|--------------------------------------------------------------------------
*/

// 1️⃣ Sales Report
$router->register(
    'GET',
    '/api/reports/sales',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->sales();
    }
);

// 2️⃣ Appointment Report
$router->register(
    'GET',
    '/api/reports/appointments',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->appointments();
    }
);

// 3️⃣ Staff Performance Report
$router->register(
    'GET',
    '/api/reports/staff-performance',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->staffPerformance();
    }
);

// 4️⃣ Service-wise Revenue Report
$router->register(
    'GET',
    '/api/reports/services',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->services();
    }
);

// 5️⃣ Package-wise Revenue Report
$router->register(
    'GET',
    '/api/reports/packages',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->packages();
    }
);

// 6️⃣ Customer Visit Report
$router->register(
    'GET',
    '/api/reports/customers',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->customers();
    }
);

// 7️⃣ Inventory Usage Report
$router->register(
    'GET',
    '/api/reports/inventory',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->inventory();
    }
);

// 8️⃣ Incentive Payout Report
$router->register(
    'GET',
    '/api/reports/incentives',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->incentives();
    }
);

// 9️⃣ Tax Report (GST)
$router->register(
    'GET',
    '/api/reports/tax',
    function() use ($controller) {
        authorize(['ADMIN', 'STAFF']);
        $controller->tax();
    }
);
