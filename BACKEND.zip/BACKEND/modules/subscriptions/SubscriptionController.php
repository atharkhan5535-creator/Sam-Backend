<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../core/Request.php';
require_once __DIR__ . '/../../core/Response.php';

class SalonSubscriptionController
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /*
    |--------------------------------------------------------------------------
    | 1️⃣ CREATE SALON SUBSCRIPTION (ADMIN only - subscribe salon to a plan)
    |--------------------------------------------------------------------------
    */
    public function create()
    {
        $auth = $GLOBALS['auth_user'] ?? null;
        $salonId = $auth['salon_id'] ?? null;

        if (!$salonId) {
            Response::json(["status" => "error", "message" => "Invalid salon context"], 400);
        }

        $data = json_decode(file_get_contents("php://input"), true);

        $planId = $data['plan_id'] ?? null;
        $startDate = $data['start_date'] ?? date('Y-m-d');

        // Validation
        if (!$planId) {
            Response::json(["status" => "error", "message" => "Plan ID is required"], 400);
        }

        // Verify plan exists and is active
        $stmt = $this->db->prepare("SELECT * FROM subscription_plans WHERE plan_id = ? AND status = 1");
        $stmt->execute([$planId]);
        $plan = $stmt->fetch();

        if (!$plan) {
            Response::json(["status" => "error", "message" => "Active plan not found"], 404);
        }

        // Calculate end date based on plan duration
        $endDate = date('Y-m-d', strtotime($startDate . " +{$plan['duration_days']} days"));

        // Check if salon already has an active subscription
        $stmt = $this->db->prepare("
            SELECT subscription_id FROM salon_subscriptions
            WHERE salon_id = ? AND status = 'ACTIVE' AND end_date >= CURDATE()
        ");
        $stmt->execute([$salonId]);
        if ($stmt->fetch()) {
            Response::json(["status" => "error", "message" => "Salon already has an active subscription"], 409);
        }

        try {
            $this->db->beginTransaction();

            // 1. Create subscription
            $stmt = $this->db->prepare("
                INSERT INTO salon_subscriptions
                (salon_id, plan_id, start_date, end_date, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, 'ACTIVE', NOW(), NOW())
            ");

            $stmt->execute([
                $salonId,
                $planId,
                $startDate,
                $endDate
            ]);

            $subscriptionId = $this->db->lastInsertId();

            // 2. Auto-create invoice for the subscription
            $amount = (float) $plan['flat_price'];
            $taxRate = 0; // Change to 18 for GST
            $taxAmount = ($amount * $taxRate) / 100;
            $totalAmount = $amount + $taxAmount;

            $invoiceNumber = 'INV-SUB-' . $salonId . '-' . date('Ymd') . '-' . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $dueDate = date('Y-m-d', strtotime('+7 days'));
            $invoiceDate = date('Y-m-d');

            $invoiceStmt = $this->db->prepare("
                INSERT INTO invoice_salon
                (salon_id, subscription_id, invoice_number, amount, tax_amount, total_amount,
                 payment_status, invoice_date, due_date)
                VALUES (?, ?, ?, ?, ?, ?, 'UNPAID', ?, ?)
            ");

            $invoiceStmt->execute([
                $salonId,
                $subscriptionId,
                $invoiceNumber,
                $amount,
                $taxAmount,
                $totalAmount,
                $invoiceDate,
                $dueDate
            ]);

            $invoiceId = $this->db->lastInsertId();

            $this->db->commit();

            Response::json([
                "status" => "success",
                "data" => [
                    "subscription_id" => $subscriptionId,
                    "invoice_id" => $invoiceId,
                    "invoice_number" => $invoiceNumber,
                    "total_amount" => $totalAmount,
                    "start_date" => $startDate,
                    "end_date" => $endDate
                ]
            ], 201);

        } catch (Exception $e) {
            $this->db->rollBack();
            Response::json([
                "status" => "error",
                "message" => "Failed to create subscription: " . $e->getMessage()
            ], 500);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | 2️⃣ UPDATE SALON SUBSCRIPTION (ADMIN only)
    |--------------------------------------------------------------------------
    */
    public function update($subscriptionId)
    {
        $auth = $GLOBALS['auth_user'] ?? null;
        $salonId = $auth['salon_id'] ?? null;

        if (!$salonId) {
            Response::json(["status" => "error", "message" => "Invalid salon context"], 400);
        }

        // Verify subscription belongs to salon
        $stmt = $this->db->prepare("SELECT * FROM salon_subscriptions WHERE subscription_id = ? AND salon_id = ?");
        $stmt->execute([$subscriptionId, $salonId]);
        $subscription = $stmt->fetch();

        if (!$subscription) {
            Response::json(["status" => "error", "message" => "Subscription not found"], 404);
        }

        $data = json_decode(file_get_contents("php://input"), true);

        $allowedFields = ['plan_id', 'start_date', 'end_date', 'status'];
        $updates = [];
        $values = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $values[] = $data[$field];
            }
        }

        if (empty($updates)) {
            Response::json(["status" => "error", "message" => "No valid fields to update"], 400);
        }

        $values[] = $subscriptionId;
        $values[] = $salonId;

        $sql = "UPDATE salon_subscriptions SET " . implode(', ', $updates) . ", updated_at = NOW()
                WHERE subscription_id = ? AND salon_id = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($values);

        Response::json([
            "status" => "success"
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 3️⃣ CANCEL SALON SUBSCRIPTION (ADMIN only)
    |--------------------------------------------------------------------------
    */
    public function cancel($subscriptionId)
    {
        $auth = $GLOBALS['auth_user'] ?? null;
        $salonId = $auth['salon_id'] ?? null;

        if (!$salonId) {
            Response::json(["status" => "error", "message" => "Invalid salon context"], 400);
        }

        // Verify subscription belongs to salon
        $stmt = $this->db->prepare("SELECT * FROM salon_subscriptions WHERE subscription_id = ? AND salon_id = ?");
        $stmt->execute([$subscriptionId, $salonId]);
        $subscription = $stmt->fetch();

        if (!$subscription) {
            Response::json(["status" => "error", "message" => "Subscription not found"], 404);
        }

        $stmt = $this->db->prepare("
            UPDATE salon_subscriptions
            SET status = 'CANCELLED', updated_at = NOW()
            WHERE subscription_id = ? AND salon_id = ?
        ");

        $stmt->execute([$subscriptionId, $salonId]);

        Response::json([
            "status" => "success"
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 4️⃣ VIEW SALON SUBSCRIPTION DETAILS (ADMIN)
    |--------------------------------------------------------------------------
    */
    public function show($subscriptionId)
    {
        $auth = $GLOBALS['auth_user'] ?? null;
        $salonId = $auth['salon_id'] ?? null;

        if (!$salonId) {
            Response::json(["status" => "error", "message" => "Invalid salon context"], 400);
        }

        $stmt = $this->db->prepare("
            SELECT ss.*, sp.plan_name, sp.duration_days, sp.plan_type, sp.flat_price
            FROM salon_subscriptions ss
            INNER JOIN subscription_plans sp ON ss.plan_id = sp.plan_id
            WHERE ss.subscription_id = ? AND ss.salon_id = ?
        ");

        $stmt->execute([$subscriptionId, $salonId]);
        $subscription = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$subscription) {
            Response::json(["status" => "error", "message" => "Subscription not found"], 404);
        }

        Response::json([
            "status" => "success",
            "data" => $subscription
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 5️⃣ GET SALON'S CURRENT SUBSCRIPTION (ADMIN)
    |--------------------------------------------------------------------------
    */
    public function getCurrentSubscription()
    {
        $auth = $GLOBALS['auth_user'] ?? null;
        $salonId = $auth['salon_id'] ?? null;

        if (!$salonId) {
            Response::json(["status" => "error", "message" => "Invalid salon context"], 400);
        }

        $stmt = $this->db->prepare("
            SELECT ss.*, sp.plan_name, sp.duration_days, sp.plan_type, sp.flat_price
            FROM salon_subscriptions ss
            INNER JOIN subscription_plans sp ON ss.plan_id = sp.plan_id
            WHERE ss.salon_id = ? AND ss.status = 'ACTIVE' AND ss.end_date >= CURDATE()
            ORDER BY ss.end_date DESC
            LIMIT 1
        ");

        $stmt->execute([$salonId]);
        $subscription = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$subscription) {
            Response::json([
                "status" => "success",
                "data" => null,
                "message" => "No active subscription found"
            ]);
        }

        Response::json([
            "status" => "success",
            "data" => $subscription
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 6️⃣ LIST SALON SUBSCRIPTION HISTORY (ADMIN)
    |--------------------------------------------------------------------------
    */
    public function index()
    {
        $auth = $GLOBALS['auth_user'] ?? null;
        $salonId = $auth['salon_id'] ?? null;

        if (!$salonId) {
            Response::json(["status" => "error", "message" => "Invalid salon context"], 400);
        }

        $status = $_GET['status'] ?? null;

        $sql = "
            SELECT ss.*, sp.plan_name, sp.duration_days
            FROM salon_subscriptions ss
            INNER JOIN subscription_plans sp ON ss.plan_id = sp.plan_id
            WHERE ss.salon_id = ?
        ";

        $params = [$salonId];

        if ($status && in_array($status, ['ACTIVE', 'EXPIRED', 'CANCELLED'])) {
            $sql .= " AND ss.status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY ss.created_at DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        Response::json([
            "status" => "success",
            "data" => [
                "items" => $subscriptions
            ]
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 7️⃣ CREATE SUBSCRIPTION FOR SALON (SUPER_ADMIN only)
    | Assign subscription plan to any salon
    |--------------------------------------------------------------------------
    */
    public function createForSalon($salonId)
    {
        $data = json_decode(file_get_contents("php://input"), true);

        $planId = $data['plan_id'] ?? null;
        $startDate = $data['start_date'] ?? date('Y-m-d');
        $endDate = $data['end_date'] ?? null;
        $status = $data['status'] ?? 'ACTIVE';

        // Validation
        if (!$planId) {
            Response::json(["status" => "error", "message" => "Plan ID is required"], 400);
        }

        // Verify salon exists
        $stmt = $this->db->prepare("SELECT salon_id, salon_name FROM salons WHERE salon_id = ?");
        $stmt->execute([$salonId]);
        $salon = $stmt->fetch();

        if (!$salon) {
            Response::json(["status" => "error", "message" => "Salon not found"], 404);
        }

        // Verify plan exists and is active
        $stmt = $this->db->prepare("SELECT * FROM subscription_plans WHERE plan_id = ? AND status = 1");
        $stmt->execute([$planId]);
        $plan = $stmt->fetch();

        if (!$plan) {
            Response::json(["status" => "error", "message" => "Active plan not found"], 404);
        }

        // Calculate end date if not provided
        if (!$endDate) {
            $endDate = date('Y-m-d', strtotime($startDate . " +{$plan['duration_days']} days"));
        }

        // Check if salon already has an active subscription
        $stmt = $this->db->prepare("
            SELECT subscription_id FROM salon_subscriptions
            WHERE salon_id = ? AND status = 'ACTIVE' AND end_date >= CURDATE()
        ");
        $stmt->execute([$salonId]);
        if ($stmt->fetch()) {
            Response::json(["status" => "error", "message" => "Salon already has an active subscription"], 409);
        }

        try {
            $this->db->beginTransaction();

            // 1. Create subscription
            $stmt = $this->db->prepare("
                INSERT INTO salon_subscriptions
                (salon_id, plan_id, start_date, end_date, status)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $salonId,
                $planId,
                $startDate,
                $endDate,
                $status
            ]);

            $subscriptionId = $this->db->lastInsertId();

            // 2. Auto-create invoice for the subscription
            $amount = (float) $plan['flat_price'];
            $taxRate = 0; // Change to 18 for GST
            $taxAmount = ($amount * $taxRate) / 100;
            $totalAmount = $amount + $taxAmount;

            $invoiceNumber = 'INV-SUB-' . $salonId . '-' . date('Ymd') . '-' . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $dueDate = date('Y-m-d', strtotime('+7 days'));
            $invoiceDate = date('Y-m-d');

            $invoiceStmt = $this->db->prepare("
                INSERT INTO invoice_salon
                (salon_id, subscription_id, invoice_number, amount, tax_amount, total_amount,
                 payment_status, invoice_date, due_date)
                VALUES (?, ?, ?, ?, ?, ?, 'UNPAID', ?, ?)
            ");

            $invoiceStmt->execute([
                $salonId,
                $subscriptionId,
                $invoiceNumber,
                $amount,
                $taxAmount,
                $totalAmount,
                $invoiceDate,
                $dueDate
            ]);

            $invoiceId = $this->db->lastInsertId();

            $this->db->commit();

            Response::json([
                "status" => "success",
                "data" => [
                    "subscription_id" => $subscriptionId,
                    "invoice_id" => $invoiceId,
                    "invoice_number" => $invoiceNumber,
                    "total_amount" => $totalAmount,
                    "start_date" => $startDate,
                    "end_date" => $endDate
                ]
            ], 201);

        } catch (Exception $e) {
            $this->db->rollBack();
            Response::json([
                "status" => "error",
                "message" => "Failed to create subscription: " . $e->getMessage()
            ], 500);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | 8️⃣ UPDATE SUBSCRIPTION BY SUPER_ADMIN
    | Update subscription dates/status for any salon
    |--------------------------------------------------------------------------
    */
    public function updateBySuperAdmin($subscriptionId)
    {
        $data = json_decode(file_get_contents("php://input"), true);

        // Verify subscription exists
        $stmt = $this->db->prepare("SELECT * FROM salon_subscriptions WHERE subscription_id = ?");
        $stmt->execute([$subscriptionId]);
        $subscription = $stmt->fetch();

        if (!$subscription) {
            Response::json(["status" => "error", "message" => "Subscription not found"], 404);
        }

        $allowedFields = ['plan_id', 'start_date', 'end_date', 'status'];
        $updates = [];
        $values = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $values[] = $data[$field];
            }
        }

        if (empty($updates)) {
            Response::json(["status" => "error", "message" => "No valid fields to update"], 400);
        }

        $values[] = $subscriptionId;

        $sql = "UPDATE salon_subscriptions SET " . implode(', ', $updates) . ", updated_at = NOW()
                WHERE subscription_id = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($values);

        Response::json([
            "status" => "success"
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | 9️⃣ LIST SUBSCRIPTIONS BY SALON (SUPER_ADMIN)
    | View all subscriptions for a specific salon
    |--------------------------------------------------------------------------
    */
    public function indexBySalon($salonId)
    {
        // Verify salon exists
        $stmt = $this->db->prepare("SELECT salon_id, salon_name FROM salons WHERE salon_id = ?");
        $stmt->execute([$salonId]);
        $salon = $stmt->fetch();

        if (!$salon) {
            Response::json(["status" => "error", "message" => "Salon not found"], 404);
        }

        $status = $_GET['status'] ?? null;

        $sql = "
            SELECT ss.*, sp.plan_name, sp.duration_days
            FROM salon_subscriptions ss
            INNER JOIN subscription_plans sp ON ss.plan_id = sp.plan_id
            WHERE ss.salon_id = ?
        ";
        $params = [$salonId];

        if ($status && in_array($status, ['ACTIVE', 'EXPIRED', 'CANCELLED'])) {
            $sql .= " AND ss.status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY ss.created_at DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        Response::json([
            "status" => "success",
            "data" => [
                "salon" => [
                    "salon_id" => $salonId,
                    "salon_name" => $salon['salon_name']
                ],
                "items" => $subscriptions
            ]
        ]);
    }
}
