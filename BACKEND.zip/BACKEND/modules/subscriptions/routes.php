<?php

require_once __DIR__ . '/SubscriptionController.php';
require_once __DIR__ . '/../../middlewares/authenticate.php';
require_once __DIR__ . '/../../middlewares/authorize.php';

$controller = new SalonSubscriptionController();

/*
|--------------------------------------------------------------------------
| SALON SUBSCRIPTION ROUTES (ADMIN - for own salon)
|--------------------------------------------------------------------------
*/

// 1️⃣ Create Salon Subscription (subscribe to a plan)
$router->register(
    'POST',
    '/api/subscriptions',
    function() use ($controller) {
        authorize(['ADMIN']);
        $controller->create();
    }
);

// 2️⃣ Update Salon Subscription
$router->register(
    'PUT',
    '/api/subscriptions/{subscription_id}',
    function($subscriptionId) use ($controller) {
        authorize(['ADMIN']);
        $controller->update($subscriptionId);
    }
);

// 3️⃣ Cancel Salon Subscription
$router->register(
    'PATCH',
    '/api/subscriptions/{subscription_id}/cancel',
    function($subscriptionId) use ($controller) {
        authorize(['ADMIN']);
        $controller->cancel($subscriptionId);
    }
);

// 4️⃣ View Subscription Details
$router->register(
    'GET',
    '/api/subscriptions/{subscription_id}',
    function($subscriptionId) use ($controller) {
        authorize(['ADMIN']);
        $controller->show($subscriptionId);
    }
);

// 5️⃣ Get Current Active Subscription
$router->register(
    'GET',
    '/api/subscriptions/current',
    function() use ($controller) {
        authorize(['ADMIN']);
        $controller->getCurrentSubscription();
    }
);

// 6️⃣ List Subscription History
$router->register(
    'GET',
    '/api/subscriptions',
    function() use ($controller) {
        authorize(['ADMIN']);
        $controller->index();
    }
);

/*
|--------------------------------------------------------------------------
| SUPER_ADMIN SUBSCRIPTION ROUTES (manage all salons)
|--------------------------------------------------------------------------
*/

// 1️⃣ Assign Subscription to Salon (SUPER_ADMIN)
$router->register(
    'POST',
    '/api/super-admin/salons/{salon_id}/subscriptions',
    function($salonId) use ($controller) {
        authorize(['SUPER_ADMIN']);
        $controller->createForSalon($salonId);
    }
);

// 2️⃣ Update Subscription Dates (SUPER_ADMIN)
$router->register(
    'PUT',
    '/api/super-admin/subscriptions/{subscription_id}',
    function($subscriptionId) use ($controller) {
        authorize(['SUPER_ADMIN']);
        $controller->updateBySuperAdmin($subscriptionId);
    }
);

// 3️⃣ View Salon Subscription History (SUPER_ADMIN)
$router->register(
    'GET',
    '/api/super-admin/salons/{salon_id}/subscriptions',
    function($salonId) use ($controller) {
        authorize(['SUPER_ADMIN']);
        $controller->indexBySalon($salonId);
    }
);
